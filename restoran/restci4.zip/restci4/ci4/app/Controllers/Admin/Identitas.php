<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\M_identitas;

class Identitas extends BaseController
{
    public function index()
    {
        $model = new M_identitas;
        $identitas = $model->findAll();
        $data = [
            'identitas' => $identitas
        ];
        
        return view('admin/identitas/identitas', $data);
    }

    public function find($id = null)
    {
        $model = new M_identitas();
        $identitas = $model->find($id);
        
        $data = [
            'identitas' => $identitas
        ];

        return view('admin/identitas/update', $data);
    }

    public function update()
    {
        $id = $this->request->getPost('idtoko');
        $icon = $this->request->getfile('icon');
        $logo = $this->request->getfile('logo');
        $checkIcon = $icon->getName();
        $checkLogo = $logo->getName();

        if (empty($checkIcon)) {
			$checkIcon = $this->request->getPost('icon');
		} else {
			$icon->move('./img/icon');
        }

        if (empty($checkLogo)) {
			$checkLogo = $this->request->getPost('logo');
		} else {
			$logo->move('./upload/logo');
		}

        $data = [
            'namatoko' => $this->request->getPost('namatoko'),
            'alamattoko' => $this->request->getPost('alamattoko'),
            'emailtoko' => $this->request->getPost('emailtoko'),
            'nomortoko' => $this->request->getPost('nomortoko'),
            'deskripsitoko' => $this->request->getPost('deskripsitoko'),
            'icon' => $checkIcon,
            'logo' => $checkLogo,
        ];

        $model = new M_identitas();
        $model->update($id, $data);
        return redirect()->to(base_url('/admin/identitas'));
    }

    //--------------------------------------------------------------------

}
