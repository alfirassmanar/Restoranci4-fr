<?php namespace App\Controllers\Admin;
use App\Controllers\BaseController;

use App\Models\M_kategori;

class Kategori extends BaseController
{
	public function index()
	{
        $model = new M_kategori;
        $kategori = $model->findAll();
		$data = [
            'kategori' => $kategori
        ];
		return view('admin/kategori/kategori',$data);
	}

	public function create()
	{
		echo view("/admin/kategori/insert");
	}

    public function insert()
	{
		$model = new M_kategori();
		if ($model->insert($_POST) === false) {
			$error = $model->errors();
			session()->setFlashdata('info', $error['kategori']);
			return redirect()->to(base_url("/admin/kategori/create"));
		} else {
			return redirect()->to(base_url("/admin/kategori"));
		};
	}

	public function find($id = null)
	{
		$model = new M_kategori();
		$kategori = $model ->find($id);
		
		$data = [
			'kategori' => $kategori
		];

		return view("admin/kategori/update",$data);
	}

	public function update()
	{
		$model = new M_kategori();
		$id = $_POST['idkategori'];
		$model->save($_POST);
		return redirect()->to(base_url("/admin/kategori"));
	}

	public function delete($id = null)
	{
		$model = new M_kategori();
		$model -> delete($id);
		return redirect()->to(base_url("/admin/kategori"));
	}

	//--------------------------------------------------------------------

}