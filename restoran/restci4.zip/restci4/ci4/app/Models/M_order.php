<?php namespace App\Models;

use CodeIgniter\Model;

class M_order extends Model
{
    protected $table = 'vorder';
}