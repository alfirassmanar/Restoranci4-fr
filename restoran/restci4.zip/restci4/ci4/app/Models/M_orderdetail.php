<?php namespace App\Models;

use CodeIgniter\Model;

class M_orderdetail extends Model
{
    protected $table = 'vorderdetail';
}