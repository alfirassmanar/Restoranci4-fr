<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
  <ul class="navbar-nav">
    <li>
      <span>User : <?php
                    if (!empty(session()->get('user'))) {
                      echo session()->get('user');
                    }
                    ?></span>
    </li>
    <li class="ml-3">
      <span>Email : <?php
                    if (!empty(session()->get('email'))) {
                      echo session()->get('email');
                    }
                    ?></span>
    </li>
    <li class="ml-3">
      <span>Level : <?php
                    if (!empty(session()->get('level'))) {
                      echo session()->get('level');
                      $level = session()->get('level');
                    }
                    ?></span>
    </li>
    <?php if (!empty(session()->get('user'))) : ?>
    <li class="ml-3"><a href="<?= base_url('/admin/login/logout') ?>">Logout</a></li>
    <?php endif ?>
  </ul>
  <!-- Right navbar links -->
</nav>
<?= $this->renderSection('admin_navbar') ?>