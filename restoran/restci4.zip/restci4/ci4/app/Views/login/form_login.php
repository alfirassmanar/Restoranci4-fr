<form class="form" method="post" action="<?= base_url('/login/index') ?>">
	<?php
	if (!empty($info)) {
		echo '<div class="alert alert-danger" role="alert">';
		echo $info;
		echo '</div>';
	}
	?>
	<div class="row">
		<div class="col-12">
			<div class="form-group">
				<label style="color : #000">Email</label>
				<input type="email" name="email" placeholder="Type your email here" required="required">
			</div>
		</div>
		<div class="col-12">
			<div class="form-group">
				<label style="color : #000">Password</label>
				<input type="password" name="password" placeholder="Type your password here" required="required">
			</div>
		</div>
		<div class="col-6 my-2 mx-auto">
			<input style="background : #ffc107" class="btn btn-warning btn-block" type="submit" name="login" value="Login">
		</div>
	</div>
</form>
<?= $this->renderSection('form_login') ?>

<a href="<?= base_url('registrasi') ?>">
	<p style="color : red; font-size: 18px">Not a member? <span>Sign Up</span></p>
</a>