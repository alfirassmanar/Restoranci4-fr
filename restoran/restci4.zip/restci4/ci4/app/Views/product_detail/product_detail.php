<?= $this->extend('template/header') ?>

<?= $this->section('header') ?>
<body class="js">
		
		<!-- Header -->
		<header class="header shop">
			<!-- Topbar -->
			<?= $this->include('template/topbar') ?>
			<!-- End Topbar -->
			<?= $this->include('template/middle_inner') ?>
			<!-- Header Inner -->
			<?= $this->include('template/head_in') ?>
			<!--/ End Header Inner -->
		</header>
		<!--/ End Header -->
	
		<!-- Breadcrumbs -->
		<div class="breadcrumbs">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="bread-inner">
							<ul class="bread-list">
								<li><a href="<?= base_url('/') ?>">Home<i class="ti-arrow-right"></i></a></li>
								<li class="active"><a href="<?= base_url('product_detail') ?>">Product Detail</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- End Breadcrumbs -->
				
		<!-- Start Product Detail -->
		<section class="shop checkout section">
			<div class="container">
				<div class="row"> 
					<div class="mx-auto col-lg-8 col-12">
						<div class="checkout-form">
							<h2 class="mb-4">Product Detail</h2>
							<!-- Form -->
							<?= $this->include('product_detail/form_detail') ?>
							<!--/ End Form -->
						</div>
					</div>
				</div>
			</div>
		</section>
		<!--/ End Product Detail -->
		
		<!-- Start Shop Services Area  -->
		<section class="shop-services section home">
			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="ti-rocket"></i>
							<h4>Free shiping</h4>
							<p>Orders over $100</p>
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="ti-reload"></i>
							<h4>Free Return</h4>
							<p>Within 30 days returns</p>
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="ti-lock"></i>
							<h4>Sucure Payment</h4>
							<p>100% secure payment</p>
						</div>
						<!-- End Single Service -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Start Single Service -->
						<div class="single-service">
							<i class="ti-tag"></i>
							<h4>Best Peice</h4>
							<p>Guaranteed price</p>
						</div>
						<!-- End Single Service -->
					</div>
				</div>
			</div>
		</section>
		<!-- End Shop Services -->
	<?= $this->include('template/footer') ?>
<?= $this->endSection() ?>