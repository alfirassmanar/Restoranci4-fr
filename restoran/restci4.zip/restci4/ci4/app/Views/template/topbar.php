<!-- Topbar -->
<div class="topbar">
	<div class="container">
		<div class="row">
			<div class="col-lg-5 col-md-12 col-12">
				<!-- Top Left -->
				<div class="top-left">
					<ul class="list-main">
						<li><i class="ti-headphone-alt"></i> <?= $identitas['nomortoko'] ?></li>
						<li><i class="ti-email"></i> <?= $identitas['emailtoko'] ?></li>
					</ul>
				</div>
				<!--/ End Top Left -->
			</div>
			<div class="col-lg-7 col-md-12 col-12">
				<!-- Top Right -->
				<div class="right-content">
					<ul class="list-main">
						<li><i class="ti-user"></i> <?php
													if (!empty(session()->get('pelanggan'))) {
														echo session()->get('pelanggan');
													} else {
														echo ' My account';
													}
													?></li>
						<?php if (empty(session()->get('pelanggan'))) : ?>
							<li><i class="ti-power-off"></i><a href="<?= base_url('/login') ?>">Login</a></li>
						<?php else : ?>
							<li><i class="ti-power-off"></i><a href="<?= base_url('/login/logout') ?>">Logout</a></li>
						<?php endif ?>
					</ul>
				</div>
				<!-- End Top Right -->
			</div>
		</div>
	</div>
</div>
<!-- End Topbar -->
<?= $this->renderSection('topbar') ?>